# PAP SMP · Peace and Purge

Creator: **yuuh92**
Projekt und Referenz: https://papsmp.de

Pflichtangabe bei Nutzung, Weitergabe oder Veröffentlichung der PAP-Inhalte:
**„PAP SMP – Peace and Purge · Creator: yuuh92 · https://papsmp.de“**

Bei Downloadangeboten steht die Angabe in der Beschreibung und bleibt als CREDITS.md im Paket erhalten. Bei Videos, Streams, Screenshots und Beiträgen gehört sie in die Beschreibung oder einen gut sichtbaren Creditbereich. Bei bearbeiteten Fassungen zusätzlich die Änderungen kenntlich machen.

Minecraft-Grundressourcen und Marken: Mojang Studios / Microsoft. Ihre jeweiligen Rechte und Bedingungen gelten unabhängig von den PAP-Credits. Die Namensnennung ersetzt keine Rechte an fremden Inhalten.

PAP SMP ist ein unabhängiges Fanprojekt und kein offizielles Minecraft-Produkt.
