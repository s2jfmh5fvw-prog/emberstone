# AKTUELLER STAND 3.2.18 – PAP Naturwerk · 20.10.2026

Diese aktuelle Ergänzung hat Vorrang vor den darunter erhaltenen historischen 3.2.16-Hinweisen. Die Dateinamen bleiben wegen bestehender Download-Verknüpfungen absichtlich bei 3.2.16; der Inhalt ist Ressourcenstand 3.2.18.

Enthalten sind die sieben freigegebenen Naturwerk-Modelle: Wurzelgeflecht, Wurzelwacht, Dornengestrüpp, Windglocke, Reifblüte, Wurzelbogen und Hainanker. Originale Herz-, Rüstungs-, Fuchs-, HUD-, UI- und Companion-Assets bleiben erhalten. Java und Bedrock benötigen ihre jeweilige Packdatei; Geyser konvertiert keine Java-Packs.

Die neue Gerätefunktion und die Trägerdarstellung benötigen PAP-SMP-DefenseTrap 1.1.0-alpha.1 aus der gesonderten minimalen Serverlieferung. Diese Ressourcen-ZIP enthält nicht automatisch diese neue Plugin-JAR und ist kein vollständiger Serverersatz. Die bestehenden Companion-/UI-JARs in diesem Archiv bleiben unverändert.

Bei einem bestehenden Server die vorhandene aktive Mappingdatei ersetzen bzw. deren Inhalt zusammenführen. Nicht dieselben Definitionen unter einem weiteren Dateinamen parallel installieren. Die Download-ZIP enthält genau eine Mappingdatei mit 3.2.16-Dateinamen; Bloom verwendet weiterhin seinen bestehenden aktiven 3.2.12-Dateinamen als Austauschziel. Die vorhandenen Pack-UUIDs sind unverändert, die Bedrock-Version wird auf 3.2.18 angehoben.

Prüfstand: Archivintegrität, alle 851 genehmigten Quader, Verweise, gleiche Java-/Bedrock-Texturatlanten, erhaltene Alt-Assets und sieben Mappingdefinitionen wurden statisch geprüft. Das ist keine bestandene grafische Java-/Bedrock-/Geyser-Abnahme. Die Trägerposition der unsichtbaren ArmorStands bleibt bis zum echten Client-Test konfigurierbar; Standard ist Modellbasis minus 1,6875 Blöcke. Keine automatische Server-Neustartfreigabe aus diesem Dokument ableiten.

Aktuelle Prüfsummen:

- SHA-256 `PAP-SMP-Full-Java-3.2.16-Karten-MC-1.21.11.zip`: `27e88e9afe3eb70e9657720c8a76bd33eac3f4dde53e9cff6181a677298892db`
- SHA-256 `PAP-SMP-Bedrock-3.2.16-Karten.mcpack`: `2ab2259b079078d5fb010eaa81d01c8ca8caf987cc9ca30e40727d476d101407`
- SHA-256 `PAP-SMP-Custom-Mappings-3.2.16.json`: `5ea00d22cb2829ad7379ba582f5909f5c86d5356cc3158598ff9ba4ad4c98882`
- Java resource-pack-sha1: `604554fab749e76564f7ed27e406c2865b08126e`

---

## Historische Hinweise – nachrangig zur Ergänzung oben

## Bedrock-Hotfix vom 19.10.2026 – interner Packstand 3.2.17

Die bisherigen Dateinamen und Downloadadressen bleiben unverändert. Die Bedrock-Pack-UUID bleibt erhalten; Header und Modulversion steigen auf 3.2.17, damit Clients den neuen Stand erkennen.

Der PAP-Eingriff in das native Pausemenü wurde entfernt. Speichern und Beenden verwendet wieder die Vanilla-Oberfläche. Bei den Bo-Chibi-Ringen wurde die zusätzliche clientseitige Drehung entfernt: Die zugehörige Serverdarstellung steuert diese Ringe bereits über separate Armor-Stands. Modelle, UVs, Texturen und die PAP-Identität wurden dabei erhalten. Die funktionalen Mapping-IDs bleiben gleich; die Downloadfassung korrigiert nur fehlerhafte Sonderzeichen in Anzeigenamen.

Die Pack-Struktur, Archive und Ressourcenverweise sind technisch geprüft. Eine grafische Java-/Bedrock-Abnahme sowie die Bedienprüfung im echten Bedrock-Client sind offen. Insbesondere ist damit keine vollständige Behebung aller gemeldeten PAP-/Bo-Darstellungsfehler nachgewiesen.

Nachfolgend die historische Beschreibung des Kartenstands 3.2.16; die obigen Hotfix-Hinweise gehen vor.

# PAP SMP 3.2.16 – Prüfbericht

Die vom Benutzer gewählte Scoreboard-Variante 2 ist kompakter und durchscheinend. Das Original-Website-Logo wird unverändert aus der Quelle abgeleitet. Karten ordnen Cash und Shards nebeneinander, während Statistikwerte rechts ausgerichtet bleiben. Das Panel misst 126 × 197 native Pixel. Vier nahtlose Logo-Kacheln vermeiden mehrfache Verkleinerung. Ein Raster mit 15 nativen Zeilen hält Minecrafts Hintergrund innerhalb der gestalteten Fläche. Es werden keine Shader oder globalen Schriftarten geändert.

Die Änderung betrifft die Sidebar und zugehörige Pack-Metadaten. TAB-Spielerliste, Nametags, Header/Footer, RTP-Oberflächen, Pausemenü und sämtliche Modelle, Texturen und Animationen von PAP/Bo bleiben unverändert. Kein neuer Besitz, keine neuen Modell-IDs und keine neue Pack-UUID. Geld wird aus derselben vorhandenen Economy gelesen; der zusätzliche UI-Formatter besitzt keine eigenen Konten oder Daten.

30 statische Prüfungen bestätigen ZIP-Integrität, gültiges JSON, unveränderte Companion-/Totem-/Elytra-Dateien und Shader, UUIDs, enge Config-Allowlist und passende Metadaten. 43 UI-Regressionsprüfungen bestätigen Pack-Gates, Textgrenzen und Cash-Ausrichtung einschließlich sehr großer und negativer Beträge. Lange Team-/Rangtexte und große Zähler werden ausschließlich für die Sidebar gekürzt; die zugrunde liegenden Konten und Daten bleiben unverändert. Native Java-Sichtprüfung: Vollbild, GUI 3 und FOV 90; Schrift, Logo, Transparenz und gehaltenes Werkzeug. Bedrock-JSON und Geyser-Packübertragung lassen sich technisch prüfen; die grafische Abnahme im Bedrock-Client bleibt separat erforderlich.
