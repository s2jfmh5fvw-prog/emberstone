# PAP SMP Alpha v1.0 RC1 – Ressourcenrevision 3.2.9

Creator: yuuh92 · https://papsmp.de

Visual-Addon 0.3.0-alpha. Lokal geprüft mit unverändertem Companion 1.1.2,
Paper 1.21.11, Java 21, Geyser 2.11.3-b1247 und ViaVersion 5.12.0.
Dieses Overlay enthält nur das neue Visual-Addon, das native Bedrock-Pack,
die synchronisierten Format-2-Mappings und Dokumentation.

Server vor dem Austausch vollständig stoppen. Alte PAP-Visual-JAR entfernen
und genau die neue JAR verwenden; Companion behalten. Alte PAP-Bedrock-Packkopien
ersetzen und die neue Mappingdatei an denselben Zielpfad kopieren. Andere Packs,
Mappings, Plugins und Konfigurationen erhalten. Die Pack-UUIDs bleiben erhalten.
Java-Pack separat unter der Server-Pack-URL bereitstellen und dessen SHA-1
aktualisieren. Geyser gameplay.force-resource-packs muss true sein.

/papvisual status <Spieler> zeigt die gemeinsame PAP-/Bo-Packprüfung.
/papvisual reload lädt nur die Visual-Konfiguration und bestätigt Java-Packs neu.
JAR-Austausch erfordert einen vollständigen Serverneustart. Drittanbieter-Hot-Reload
von Plugin-JARs ist kein unterstützter Installationsweg.

Statische Prüfung, echter Packtransport und serverseitige Modellzuordnung sind
bestanden. Grafische Java-/Bedrock-Abnahme und Produktivserver-Abnahme sind offen.
