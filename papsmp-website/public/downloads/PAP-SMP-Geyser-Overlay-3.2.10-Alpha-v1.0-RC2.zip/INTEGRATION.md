# PAP SMP Geyser-Overlay · Alpha v1.0 RC2 · 3.2.10

Nur die drei Nutzdateien unter plugins/ auf den gestoppten Testserver übertragen.
Die alte Visual-JAR ersetzen; genau eine Visual-JAR und eine PAP-Bedrock-Packkopie laden.
Packs, Welt-/Spielerdaten und andere Plugins bleiben erhalten.

Visual 0.3.1-alpha enthält die neuen Packhashes; Companion 1.1.2 bleibt Voraussetzung.
Die 28 bestehenden Custom-Mappings sind bytegleich; Eventbilder benötigen keine Item-Mappings.
Bedrock-Pack-UUID: db742887-aab4-45b8-a41a-58433fd13b5b; Version: 3.2.10.

Worldevents 1.0.1-hud.1 versendet bereits native Floodgate-SimpleForms.
Für den ausdrücklich gewünschten Alpha-Test ist bedrock-images-enabled: true
in der beigefügten Integrationskonfiguration vorbereitet. Die echte Bild-/Touch-/
Gamepad-Abnahme bleibt offen. Keine globale JSON-UI und kein Behavior-Pack.

Details und Java-Konfiguration stehen im Gesamtpaket unter 03_INTEGRATION/.
