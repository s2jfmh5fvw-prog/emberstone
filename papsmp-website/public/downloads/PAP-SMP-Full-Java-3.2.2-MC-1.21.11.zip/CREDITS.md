# PAP SMP – Creator- und Transparenzhinweis

Dieses PAP-SMP-Projekt wurde von **yuuh92** erstellt. Bitte nenne bei Nutzung, Weitergabe, Bearbeitung oder Referenzierung **yuuh92** und **PAP SMP** als Urheberhinweis und verlinke, sofern möglich, auf die ursprüngliche Projektseite. Dieser Wunsch ersetzt keine Lizenz und begründet keine weitergehenden Rechte. Fremde Bestandteile bleiben ihren jeweiligen Urhebern und Lizenzen zugeordnet.

Einzelne Texte, Dokumentation sowie ausgewählte technische oder gestalterische Inhalte wurden mit KI-Unterstützung geprüft oder optimiert. Auswahl, Integration und finale Verantwortung für diese Lieferung liegen bei yuuh92.

PAP SMP ist ein unabhängiges Fanprojekt. Es ist kein offizielles Minecraft-Produkt und wird weder von Mojang Studios/Microsoft genehmigt noch mit ihnen verbunden. Minecraft ist eine Marke von Mojang Studios/Microsoft.

Für die enthaltenen vorhandenen PAP-Bildvorlagen wurden in einer früheren Projektphase teilweise KI-Bildwerkzeuge eingesetzt. Diese Finalisierung hat keine neuen KI-Bilder erzeugt; sie verwendet deterministische Pixelanpassungen und Exporte.
