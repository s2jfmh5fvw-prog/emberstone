# PAP SMP — Vanilla First + PAPI 3.2.2

Bestehende PAP-SMP-Artworks und Spielinhalte: aus dem gesicherten FULL-Paket 3.1.0-alpha.1.
Das vorhandene feste Totem und die frühere Asche/Amethyst-Materialvorlage wurden in einem vorausgehenden Task mit OpenAI Imagegen erstellt. Diese Lieferung verwendet deterministische Pixelbearbeitung; es wurde kein neues KI-Bild erzeugt. Die Rüstungspalette und Exporte stammen aus der bestehenden PAP-Fortsetzung. Es wird keine neue öffentliche Lizenz im Namen des Eigentümers vergeben.
PAPI: am 24.09.2026 freigegebene Pixeltextur; Original-Modell und Original-Animationen des jeweiligen Clients.
Die Vanilla-GUI bleibt außerhalb der gezielten HUD-Symbole geerbt. Lebens-, Hunger-, Rüstungs- und Statusrahmen-Pixel wurden aus dem offiziellen Java-1.21.11-Client bzw. den Mojang-Bedrock-Samples v1.21.130.3 als modifizierte Texturvorlagen übernommen und in der PAP-Palette deterministisch umgefärbt; Größe, Alpha-Maske und Funktionszustände blieben erhalten. Keine HUD-Textur eines fremden Community-Packs wurde übernommen.
Originales PAP-Panorama und Logo bleiben erhalten. Logo-Pixel wurden nicht neu gezeichnet oder interpoliert.
Java- und Bedrock-Totem: dasselbe statische 128×128-Ruhebild mit 64 Farben. Die vorherige Java-Animation wurde entfernt; Motiv und erster Frame sind pixelgleich zum unveränderten Bedrock-Bild.

Technische Referenzen (nicht als Vollkopie mitgeliefert):
- Minecraft Java 1.21.11 Client: FoxModel, LogoRenderer, PanoramaRenderer, Resourcepack-Format 75.0.
- https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-11
- https://github.com/Mojang/bedrock-samples/tree/v1.21.130.3/resource_pack
- HUD-Assetpfade: https://github.com/Mojang/bedrock-samples/tree/v1.21.130.3/resource_pack/textures/ui
- https://learn.microsoft.com/en-us/minecraft/creator/documents/createanimatedblocktexture?view=minecraft-bedrock-stable
- https://learn.microsoft.com/en-us/minecraft/creator/reference/content/itemreference/examples/itemcomponents/minecraft_icon?view=minecraft-bedrock-stable
- https://geysermc.org/wiki/geyser/custom-items/
- https://geysermc.org/wiki/geyser/packs/

Frühere reine Gestaltungsreferenzen: STONEBORN (Sindavar), Volcanic Dark (TheBlondBoy), Default Dark Mode (nebuIr), Arctic Fox Totem, Furry Fox Totem und Totem 3D. Aus diesen Packs wurden keine Textur- oder Modelldateien übernommen. Das frühere Asche/Amethyst-GUI ist entfernt. Die vollständige frühere Quellenliste liegt in der lokalen Sicherung und unter audit/ORIGINAL-CREDITS.md.
PAP SMP ist ein unabhängiges Fanprojekt. Es ist kein offizielles Minecraft-Produkt und wird weder von Mojang Studios/Microsoft genehmigt noch mit ihnen verbunden. Minecraft ist eine Marke von Mojang Studios/Microsoft.

Lokal statisch geprüft. Java-/Bedrock-Clientabnahme, Shaderprüfung und Live-Geyser-Test stehen aus.
