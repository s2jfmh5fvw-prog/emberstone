# PAP SMP · Alpha v1.0 RC2 · Event-Einladungen

Ressourcenstand **3.2.10**. Java, natives Bedrock-Pack und Geyser-Auslieferung sind vorbereitet. **Bedrock-Formularbilder sind im mitgelieferten Alpha-Update aktiviert.** Bestehende Totem-, PAP-/Bo-, Purge-/Peace-, Herz-, Rüstungs-, Item- und Menüassets bleiben unverändert gegenüber RC1.

1. `INSTALLATION_UND_ROLLBACK.md` lesen und den Testserver stoppen.
2. Worldevents **1.0.1-hud.1** aus dem bestehenden Event-Chat muss installiert sein. Der separat entstehende Java-Dialog-Datapack kommt aus dem Datapack-Chat.
3. `07_AKTIVIERTES_UPDATE/` enthält genau drei Server-Nutzdateien plus Einspielhilfe und Konfigurationsergänzungen. Die Einspielhilfe zunächst als Vorschau ausführen, danach bei gestopptem Server anwenden.
4. Server starten, Java-Pack akzeptieren, Bedrock über Geyser/Floodgate verbinden und `06_PRUEFUNG/CLIENT_ABNAHMEMATRIX.csv` abarbeiten.

Ohne Event-UI-Datapack nutzt Java den vorhandenen lesbaren nativen Ersatzdialog, noch ohne Event-Icons. Bedrock-Formulare mit Bildern benötigen diesen Datapack nicht. Diese Lieferung implementiert keine Datapack-Funktionen und verändert keine Eventzustände oder Spieler-Abschaltungen.

## Inhalt

- `01_PACKS/`: vollständiges Java-Pack und ergänzendes Travel-Menü. Im entpackten lokalen Lieferordner außerdem separate Bedrock-, Geyser-Overlay- und Mapping-Downloads.
- `02_TESTPAKETE/`: kleine, getrennte Java-/Bedrock-Grafiktests; keine vollständigen PAP-Packs.
- `03_INTEGRATION/`: verbindlicher Vertrag unverändert, Zuordnung, Textkomponenten und Datapack-Handoff.
- `04_VORSCHAUEN/`: Iconübersicht und Skalierungsvergleich, beide außerhalb von Minecraft erzeugt.
- `05_DESIGN_QUELLEN/`: acht editierbare SVG-Quellen und Designfarben für spätere Menüdialoge.
- `06_PRUEFUNG/`: Originalinventar, Änderungsrahmen, Hash-Differenzen, Transport-/Komponentenprüfungen und offene Clientabnahme.
- `07_AKTIVIERTES_UPDATE/`: natives vollständiges Bedrock-Pack unter `plugins/Geyser-Spigot/packs/PAP-SMP-Bedrock-Alpha.mcpack`, unveränderte Mappings und Visual-Zusatz 0.3.1-alpha.
- `08_ADDON_QUELLE/`: wiederherstellbare Quelle des bestehenden Visual-Zusatzes mit aktualisierten Packhashes.

Das Website-Gesamt-ZIP enthält die große Bedrock-Datei nur einmal unter dem aktivierten Update, statt sie zusätzlich im Overlay-ZIP zu duplizieren. Es enthält sämtliche benötigten Java-/Bedrock-/Geyser-Nutzdateien. Die fünf Einzel-Downloads sind zusätzlich auf der Website verlinkt. UUIDs und Nutzdaten unterscheiden sich nicht zwischen diesen Lieferformen.

**Technisch geprüft, native Clientabnahme offen.** Kein Minecraft-Server wurde mit dieser Lieferung aktualisiert. Eine Website-Veröffentlichung ersetzt keine Serverinstallation. Alle Geräte-/GUI-/Touch-/Gamepad- und parallelen Purge-Sichttests sind gesondert zu bestätigen.
