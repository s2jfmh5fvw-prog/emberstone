"""Bounded PAP Events UI Alpha installer, Python 3.10+, standard library only.
Default: read-only plan. --apply requires a stopped server and explicit path.
No worlds, player data, plugin state, security/auth settings or unrelated JARs.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, shutil, sys, zipfile

HERE=Path(__file__).resolve().parent
KEY=re.compile(r'^( *)([A-Za-z0-9_-]+):(?:\s*(.*))?$')
INVITATION={'enabled':'true','countdown-bar':'true','java-datapack-enabled':'true',
            'java-datapack-id':"'file/PAP-Events-UI'",'bedrock-images-enabled':'true'}

def sha(data): return hashlib.sha256(data).hexdigest()
def within(path,parent): return path==parent or parent in path.parents
def plugin_meta(path):
    try:
        with zipfile.ZipFile(path) as z: text=z.read('plugin.yml').decode('utf-8-sig')
        def value(key):
            m=re.search(r'^'+re.escape(key)+r':\s*[\'"]?([^\r\n\'"]+)',text,re.M)
            return m.group(1).strip() if m else ''
        return value('name'),value('version')
    except (zipfile.BadZipFile, KeyError, UnicodeError): return '',''

def patch_yaml(data,updates):
    """Replace named scalar keys; preserve every unrelated line and comment.
    Refuse complex/ambiguous YAML rather than reserialize or erase it.
    """
    text=data.decode('utf-8-sig'); bom=data.startswith(b'\xef\xbb\xbf')
    eol='\r\n' if '\r\n' in text else '\n'
    lines=text.splitlines()
    if any('\t' in line[:len(line)-len(line.lstrip())] for line in lines):
        raise ValueError('YAML enthält Tabs in Einrückungen; bitte manuell ergänzen.')
    for path,value in updates.items():
        start,end,parent_indent=0,len(lines),-2
        for depth,key in enumerate(path):
            expected=parent_indent+2
            matches=[]
            for i in range(start,end):
                m=KEY.match(lines[i])
                if m and len(m.group(1))==expected and m.group(2)==key: matches.append(i)
            if len(matches)>1: raise ValueError('Doppelter YAML-Schlüssel: '+'.'.join(path[:depth+1]))
            leaf=depth==len(path)-1
            if not matches:
                insert=end
                if insert and not lines[insert-1].strip(): insert-=1
                new=[' '*expected+key+':'+(' '+value if leaf else '')]
                if not leaf:
                    for j in range(depth+1,len(path)):
                        new.append(' '*(expected+2*(j-depth))+path[j]+':'+(' '+value if j==len(path)-1 else ''))
                lines[insert:insert]=new
                break
            index=matches[0];m=KEY.match(lines[index]);scalar=(m.group(3) or '').strip()
            block_end=index+1
            while block_end<end:
                line=lines[block_end]
                if line.strip() and not line.lstrip().startswith('#') and len(line)-len(line.lstrip())<=expected: break
                block_end+=1
            if leaf:
                if any(x.strip() and not x.lstrip().startswith('#') for x in lines[index+1:block_end]):
                    raise ValueError('Skalarwert enthält untergeordnete YAML-Daten: '+'.'.join(path))
                if scalar.startswith(('|','>','&','*','{','[')):
                    raise ValueError('Komplexer YAML-Wert: '+'.'.join(path))
                comment=(' '+scalar[scalar.index('#'):]) if '#' in scalar else ''
                lines[index]=' '*expected+key+': '+value+comment
            else:
                if scalar and not scalar.startswith('#'):
                    raise ValueError('Inline-YAML-Block: '+'.'.join(path[:depth+1]))
                start,end,parent_indent=index+1,block_end,expected
    result=(eol.join(lines)+eol).encode('utf-8')
    return (b'\xef\xbb\xbf'+result) if bom else result

def patch_properties(data,updates):
    text=data.decode('utf-8-sig');eol='\r\n' if '\r\n' in text else '\n';lines=text.splitlines()
    for key,value in updates.items():
        hits=[i for i,line in enumerate(lines) if re.match(r'^\s*'+re.escape(key)+r'\s*[=:]',line)]
        if len(hits)>1: raise ValueError('Doppelter Properties-Schlüssel: '+key)
        if hits: lines[hits[0]]=key+'='+value
        else: lines.append(key+'='+value)
    out=(eol.join(lines)+eol).encode('utf-8')
    return b'\xef\xbb\xbf'+out if data.startswith(b'\xef\xbb\xbf') else out

def plan(server,manifest):
    if not (server/'server.properties').is_file() or not (server/'plugins').is_dir():
        raise ValueError('Serverwurzel muss server.properties und plugins enthalten.')
    jars={}
    for p in sorted((server/'plugins').glob('*.jar')):
        name,version=plugin_meta(p)
        if name: jars.setdefault(name,[]).append((p,version))
    required=['PAP-SMP-Worldevents','Geyser-Spigot','floodgate','PAP-SMP-Companion']
    for name in required:
        if len(jars.get(name,[]))!=1: raise ValueError('Genau eine Installation erforderlich: '+name)
    if jars['PAP-SMP-Worldevents'][0][1]!='1.0.1-hud.1':
        raise ValueError('Worldevents 1.0.1-hud.1 aus dem vorhandenen Event-Chat zuerst installieren; dieses Grafikpaket ersetzt kein Worldevents-JAR.')
    conf=server/'plugins/PAP-SMP-Worldevents/config.yml'; geyser=server/'plugins/Geyser-Spigot/config.yml'
    if not conf.is_file() or not geyser.is_file(): raise ValueError('Vorhandene Worldevents-/Geyser-Konfiguration fehlt.')
    invitation=dict(INVITATION);invitation['java-resource-pack-id']="'"+manifest['java_resource_pack_id']+"'"
    props=(server/'server.properties').read_bytes()
    level=re.search(r'^level-name\s*[=:]\s*(.+)$',props.decode('utf-8-sig'),re.M)
    world=server/(level.group(1).strip() if level else 'world')
    if not within(world.resolve(),server): raise ValueError('level-name liegt außerhalb der Serverwurzel; Datapack-Pfad manuell prüfen.')
    if (world/'datapacks/PAP-Events-UI.zip').is_file() and not (world/'datapacks/PAP-Events-UI').is_dir():
        invitation['java-datapack-id']="'file/PAP-Events-UI.zip'"
    datapack_present=(world/'datapacks/PAP-Events-UI').is_dir() or (world/'datapacks/PAP-Events-UI.zip').is_file()
    targets={server/'server.properties':patch_properties(props,{
        'resource-pack':manifest['java_url'],'resource-pack-sha1':manifest['java_sha1'],
        'resource-pack-id':manifest['java_resource_pack_id']}),
        conf:patch_yaml(conf.read_bytes(),{('presentation','invitation',k):v for k,v in invitation.items()}),
        geyser:patch_yaml(geyser.read_bytes(),{('gameplay','force-resource-packs'):'true'})}
    for name,expected in manifest['files'].items():
        source=(HERE/name).resolve();target=(server/name).resolve()
        if not within(source,HERE) or not within(target,server): raise ValueError('Ungültiger Payload-Pfad')
        data=source.read_bytes()
        if sha(data)!=expected: raise ValueError('Payload-Prüfsumme falsch: '+name)
        targets[target]=data
    addon=[name for name in manifest['files'] if name.endswith('.jar')][0]
    obsolete=[p for p,_ in jars.get('PAP-SMP-Companion-Visual',[]) if p.resolve()!=(server/addon).resolve()]
    for target in [*targets,*obsolete]:
        if not within(target.resolve(),server): raise ValueError('Ziel liegt außerhalb der Serverwurzel.')
    changes={p:data for p,data in targets.items() if not p.is_file() or p.read_bytes()!=data}
    return changes,obsolete,datapack_present

def main(argv=None):
    parser=argparse.ArgumentParser(description='PAP Events UI RC2 – standardmäßig nur Vorschau')
    parser.add_argument('--server-root',required=True)
    parser.add_argument('--apply',action='store_true',help='Nur bei gestopptem Server verwenden')
    parser.add_argument('--backup-root',help='Außerhalb der Serverwurzel und des Updatepakets')
    args=parser.parse_args(argv)
    server=Path(args.server_root).resolve()
    if within(server,HERE) or within(HERE,server): raise ValueError('Server und Updatepaket müssen getrennt liegen.')
    manifest=json.loads((HERE/'UPDATE_MANIFEST.json').read_text(encoding='utf-8'))
    changes,obsolete,datapack=plan(server,manifest)
    report={'mode':'APPLY' if args.apply else 'DRY_RUN','server_root':str(server),
            'bedrock_images_enabled':True,'java_datapack_present':datapack,
            'files_to_write':[p.relative_to(server).as_posix() for p in changes],
            'obsolete_visual_jars':[p.relative_to(server).as_posix() for p in obsolete]}
    if not datapack: print('HINWEIS: Event-UI-Datapack fehlt. Java nutzt den lesbaren nativen Ersatzdialog, noch ohne Event-Icons.')
    if args.apply and (changes or obsolete):
        base=Path(args.backup_root).resolve() if args.backup_root else server.parent/'PAP-EventsUI-Backups'
        if within(base,server) or within(base,HERE): raise ValueError('Backup muss außerhalb von Server und Updatepaket liegen.')
        stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f');backup=base/stamp
        backup.mkdir(parents=True,exist_ok=False);records=[]
        for target in [*changes,*obsolete]:
            relative=target.relative_to(server).as_posix();exists=target.is_file()
            record={'path':relative,'existed':exists}
            if exists:
                dest=backup/relative;dest.parent.mkdir(parents=True,exist_ok=True)
                data=target.read_bytes();dest.write_bytes(data);record['sha256']=sha(data)
                if sha(dest.read_bytes())!=record['sha256']: raise ValueError('Backup-Prüfung fehlgeschlagen: '+relative)
            records.append(record)
        recovery={'server_root':str(server),'files':records,'created_before_writes':True}
        (backup/'BACKUP_MANIFEST.json').write_text(json.dumps(recovery,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        for target,data in changes.items():
            target.parent.mkdir(parents=True,exist_ok=True)
            temporary=target.with_name(target.name+'.pap-events-ui.tmp');temporary.write_bytes(data)
            os.replace(temporary,target)
            if sha(target.read_bytes())!=sha(data): raise ValueError('Schreibprüfung fehlgeschlagen: '+str(target))
        for target in obsolete: target.unlink()
        report['backup']=str(backup)
        report['backup_copies_sha256_verified']=True
        (backup/'UPDATE_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return report

if __name__=='__main__':
    try: main()
    except Exception as error:
        print('ABGEBROCHEN: '+str(error),file=sys.stderr);sys.exit(1)
