# Wiederverwendbare Event-Designelemente

Ruhige Orange-/Violetttöne; helle Konturen und kompakte Formen auf transparentem Grund. Acht eigenständige Piktogramme auf 32er Gestaltungsraster, als 64 × 64 PNG ohne teiltransparenten Rand exportiert. Java und Bedrock verwenden byteidentische neue Icongrafiken.

Farben und Quellzeichnungen liegen in `05_DESIGN_QUELLEN/`. Textfarben: Creme `#EEE5D5`, warmer Akzent `#E7BE88`; Icons nicht über Text einfärben. Native Buttons und Schriftgrößen bleiben vom Client gesteuert. Informationen werden nicht allein über Farbe oder ein Symbol vermittelt.

Für spätere `/menu`-Dialoge können dieselben SVG-Grundformen, Farben und Paddingregeln wiederverwendet werden. Diese Lieferung verändert das vorhandene Travel-/Server-Menü nicht. Keine allgemeine `gui/`, Inventory-, Standardfont- oder Button-Textur ersetzen. Das weiße Event-Fuchs-Piktogramm ist nur ein Einladungsicon; bestehende Fuchs-/PAP-/Bo-Modelle und Skins bleiben geschützt.
