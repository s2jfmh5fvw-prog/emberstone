# PAP Events UI – Schnittstelle v1

Stand: 05.10.2026. Event-Plugin: PAP-SMP-Worldevents 1.0.1-hud.1. Ziel: Paper/Minecraft Java 1.21.11, Java 21; Geyser/Floodgate optional.

Isolierter Quellstand: `C:\Users\licht\Documents\Codex\2026-10-03\au\work\events-hud-v1.0.1\src\main\java\de\yuuh92\worldevents`. `EventType.java` enthält die aktuellen Aufgaben und Mindestteilnehmerzahlen.

## Zuständigkeit

Worldevents besitzt Eventzustand, Spielereignung, Aktivität, Teilnahme, Belohnungen, Einladungs-Tickets und die dauerhafte Einstellung. Das Datapack liefert ausschließlich die Java-Dialogdarstellung. Das Resourcepack liefert optionale Grafiken/Schriftzeichen. Bedrock-Formulare versendet das vorhandene Worldevents-Plugin über die Floodgate-API; ein Java-Datapack versendet diese Formulare nicht.

Eine Einladung ist ein bedienbarer Dialog bzw. ein Formular. Die ergänzende Bossbar ist eine nicht anklickbare HUD-Anzeige. Teilnahme erfordert einen Button oder `/events join` und die eigene Anreise. Keine automatische Anmeldung oder Teleportation.

## Datapack

Installationsname als Ordner: `PAP-Events-UI`; aktivierte Paper-ID: `file/PAP-Events-UI`. Bei ZIP-Installation heißt die ID `file/PAP-Events-UI.zip`; entsprechend `presentation.invitation.java-datapack-id` anpassen. Namespace: `pap_events_ui`.

Je Eventtyp genau diese zwei öffentlichen Einstiegspunkte:

- `pap_events_ui:invite_plain/<event-id>`
- `pap_events_ui:invite_pack/<event-id>`

Event-IDs in Glyph-Reihenfolge:

| Event-ID | Deutscher Name | Font-Glyph |
|---|---|---|
| lost-cargo | Verlorene Fracht | U+E600 |
| traveling-trader | Wandernder Tauschhändler | U+E601 |
| stray-fox | Fuchs auf Abwegen | U+E602 |
| glowing-fishing-spot | Leuchtende Angelstelle | U+E603 |
| supply-drop | Versorgungslieferung | U+E604 |
| lost-caravan | Verirrte Karawane | U+E605 |
| starfall | Sternenfall | U+E606 |
| world-rift | Weltenriss | U+E607 |

Serverseitiger Aufruf im Kontext des eingeladenen Spielers:

```mcfunction
execute as <Spieler-UUID> at @s run function pap_events_ui:invite_plain/lost-cargo {ticket:"<Ticket-UUID>",seconds:30,remaining:150,running:0,distance:123,x:10,y:64,z:-20}
```

`ticket` ist eine vom Plugin erzeugte UUID. Alle anderen Argumente sind Zahlen: `seconds` bis zum frühesten Start (0 bei laufendem/wartendem Event), `remaining` bis Laufzeitende bzw. bis zum Ende der Anreise-Wartefrist, `running` 0 oder 1, `distance` horizontale Entfernung in Blöcken, `x/y/z` Eventort. Keine Spielereingaben oder Namen als Makrotext einsetzen.

Die Funktionen müssen den echten Rückgabewert der Dialoganzeige weitergeben: abschließend `$return run dialog show @s <Dialogdefinition mit Makros>`, gegebenenfalls über Hilfsfunktionen mit `return run function`. Positiver Wert bedeutet Anzeige an mindestens einen Spieler; bei Fehlschlag kein künstliches `return 1` und kein Fehler als Erfolg quittieren. Das Plugin liest diesen Wert mit `execute store result score ui_<ticket-ohne-bindestriche> pap_evt_ui run ...`. Das temporäre Score wird anschließend gelöscht. Das Plugin verwaltet das unsichtbare `dummy`-Objective `pap_evt_ui`; das Datapack soll dieses Objective weder löschen noch als Sidebar nutzen.

Dialog: `minecraft:multi_action`, `pause:false`, `can_close_with_escape:true`, `after_action:"close"`. Drei Aktionen:

- Teilnehmen → `minecraft:run_command`, `command:"/events ui accept $(ticket)"`
- Eventmeldungen ausschalten → `minecraft:run_command`, `command:"/events ui mute $(ticket)"`
- Diesmal nicht → `exit_action` mit `minecraft:run_command`, `command:"/events ui dismiss $(ticket)"`; ESC nutzt diesen Ausstieg.

`plain` verwendet Standardtext und keine Custom-Glyphs. `pack` darf die explizite Schrift `pap_events_ui:icons` verwenden, muss aber jeden Eventnamen lesbar ausschreiben. Die Anzeige ist eine Momentaufnahme; der Countdown aktualisiert sich in der Plugin-Bossbar. Wartephase bei `running:0` und `seconds:0` korrekt benennen: Start wartet auf aktive Teilnehmer vor Ort.

## Resourcepack

Java-Font: `assets/pap_events_ui/font/icons.json`, Referenz `pap_events_ui:icons`, Glyphs siehe Tabelle. Grafiken unter `assets/pap_events_ui/textures/`. Keinen globalen Standardfont überschreiben. Der Spieltext bleibt ohne Pack lesbar. Plugin-Bossbars sind zunächst Standardtext; das Datapack gestaltet den Dialog.

Bedrock: PNGs `textures/pap_events_ui/<event-id>.png`. Floodgate-Formular verwendet Bildtyp PATH und den Pfad `textures/pap_events_ui/<event-id>` ohne Dateiendung. Grafiken sind optional; Formtexte und Buttons sind vollständig ohne Pack verfügbar.

Geyser konvertiert Java-Packs nicht. Java-Pack, natives Bedrock-Pack und gegebenenfalls bestehende Geyser-Auslieferung getrennt prüfen. Floodgate ist für UUID-Erkennung und Formularversand zuständig, nicht für Grafik-Konvertierung.

## Konfiguration und Fallback

Neue Konfigurationswerte befinden sich unter `presentation.invitation`; alte Konfigurationen funktionieren über Code-Defaults:

```yaml
enabled: true
countdown-bar: true
java-datapack-enabled: true
java-datapack-id: 'file/PAP-Events-UI'
java-resource-pack-id: ''
bedrock-images-enabled: false
```

`java-resource-pack-id` erst auf die tatsächlich ausgelieferte UUID eines Packs setzen, das den obigen Font enthält. Erst `SUCCESSFULLY_LOADED` für genau diese UUID aktiviert `invite_pack`; andere erfolgreiche Packs reichen nicht. Bei deaktiviertem/fehlendem Datapack oder Rückgabefehler zeigt das Plugin einen einfachen nativen Java-Dialog. Geyser-Spieler ohne verfügbare Floodgate-Formulare erhalten Chat-Buttons. `bedrock-images-enabled` erst nach erfolgreichem Bedrock-Pack-/Formulartest einschalten.

## Spielerbefehle und Sicherheit

`/events hud` schaltet um. `on`, `off`, `toggle`, `status` werden unterstützt. `/events messages` verwendet dieselbe Einstellung; bestehende `preferences.<UUID>.muted` in `state.yml` bleiben wirksam. Die Abschaltung betrifft Einladungen, Event-HUD, allgemeine Ankündigungen und Richtungshinweise. Manuelle Teilnahme bleibt möglich; persönliche Aufgaben-/Ergebnisnachrichten bleiben erhalten.

Einladung einmal je Spieler und Event; aktive/eignungsberechtigte Spieler in derselben Welt und innerhalb des bestehenden Ankündigungsradius. Während eines serverseitig geöffneten Inventars, eines Combat-Status oder kurz nach Schaden wird die Einladung zurückgestellt. Ein bereits geschlossener Dialog wird nicht ständig erneut geöffnet. Tickets sind Spieler und Event zugeordnet, einmalig, zeitlich begrenzt und nach Eventende/Neustart ungültig. Alte offene Screens können noch sichtbar sein; alte Buttons werden abgewiesen. Fremde Dialoge/Formulare werden nicht pauschal geschlossen.

## Getrennte Abnahme

Build, Unit-Tests und ein lokaler Paper-API-/Makrotest ersetzen keine Sichtprüfung. Offen: echte Java- und Bedrock-Clients, unterschiedliche GUI-Skalierungen, ESC/Touch/Gamepad, fehlendes/abgelehntes Pack, Geyser/Floodgate-Formularversand und gleichzeitige Purge-Anzeige. Das Diagnose-Datapack im lokalen Testserver ist lediglich eine Makro-Testattrappe und kein fertiges UI-Datapack.
