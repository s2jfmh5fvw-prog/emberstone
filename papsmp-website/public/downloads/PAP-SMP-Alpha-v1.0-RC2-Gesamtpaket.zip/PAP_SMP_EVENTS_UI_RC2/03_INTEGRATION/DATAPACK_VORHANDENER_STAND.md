# Separat vorhandener Java-Dialog-Datapack

Beim Abschluss dieser Pack-Erweiterung lag der bereits im anderen Chat erzeugte Datapack vor:

`C:\Users\licht\Documents\Codex\2026-10-05\erstelle-lokal-das-pap-smp-datapack\outputs\PAP-Events-UI.zip`

SHA-256: `7c77ed97692bf9639b5d4bc2929fe6d14322b223ed657953ee806e9caadc397d`.

Der Stand wurde ausschließlich gelesen. Alle 16 öffentlichen Pack-/Plain-Endpunkte und alle acht Glyph-/Font-/Namens-/Aufgaben-Zuordnungen passen zu den gelieferten Packgrafiken. Keine Datapack-Datei wurde hier geändert oder in ein echtes Serverabbild kopiert. Der Datapack wird weiterhin aus seinem eigenen Chat geliefert.

Zum vollständigen Java-Test dieses vorhandene ZIP unverändert in `<Hauptwelt>/datapacks/` installieren und `java-datapack-id: 'file/PAP-Events-UI.zip'` verwenden. Die Einspielhilfe erkennt diesen vorhandenen ZIP-Namen. Alternativ den dort ebenfalls gelieferten Ordner und `file/PAP-Events-UI` verwenden, niemals beide gleichzeitig.

Der vorhandene Datapack setzt die Glyphs in den nativen Dialogtitel. Dessen 16-Pixel-Fontdarstellung, besonders bei langen Eventnamen und großen GUI-Skalierungen, muss im nativen Client geprüft werden. Die zusätzlichen Komponentenbeispiele dieses Grafikpakets zeigen als spätere Alternative eine gepolsterte Body-Überschrift; sie verändern den vorhandenen Datapack nicht.

Die technischen Datapack-Prüfungen und ihre eigene Client-Abnahme stammen aus dem anderen Chat. Die in diesem Grafikpaket dokumentierten Transporttests liefen ohne diesen Datapack; sie belegen daher keinen ausgeführten Pack-Dialog. `DATAPACK_VERTRAGSABGLEICH.json` dokumentiert ausschließlich den gelesenen Schnittstellenabgleich.
