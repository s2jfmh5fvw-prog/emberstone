PAP SMP / Creator yuuh92 / https://papsmp.de
Alpha 3.2.7 packs; Visual 0.2.3-alpha based on supplied 0.2.2. Tested with repaired Companion 1.1.2. Stop server, back up packs/mapping/addon, replace old PAP copies (do not load two addon JARs or packs), keep Companion. UUIDs preserved. No private configuration or secrets shipped. Graphics require a client check.
