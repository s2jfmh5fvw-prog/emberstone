# AKTUELLER STAND 3.2.18 – PAP Naturwerk · 20.10.2026

Diese aktuelle Ergänzung hat Vorrang vor den darunter erhaltenen historischen 3.2.16-Hinweisen. Die Dateinamen bleiben wegen bestehender Download-Verknüpfungen absichtlich bei 3.2.16; der Inhalt ist Ressourcenstand 3.2.18.

Enthalten sind die sieben freigegebenen Naturwerk-Modelle: Wurzelgeflecht, Wurzelwacht, Dornengestrüpp, Windglocke, Reifblüte, Wurzelbogen und Hainanker. Originale Herz-, Rüstungs-, Fuchs-, HUD-, UI- und Companion-Assets bleiben erhalten. Java und Bedrock benötigen ihre jeweilige Packdatei; Geyser konvertiert keine Java-Packs.

Die neue Gerätefunktion und die Trägerdarstellung benötigen PAP-SMP-DefenseTrap 1.1.0-alpha.1 aus der gesonderten minimalen Serverlieferung. Diese Ressourcen-ZIP enthält nicht automatisch diese neue Plugin-JAR und ist kein vollständiger Serverersatz. Die bestehenden Companion-/UI-JARs in diesem Archiv bleiben unverändert.

Bei einem bestehenden Server die vorhandene aktive Mappingdatei ersetzen bzw. deren Inhalt zusammenführen. Nicht dieselben Definitionen unter einem weiteren Dateinamen parallel installieren. Die Download-ZIP enthält genau eine Mappingdatei mit 3.2.16-Dateinamen; Bloom verwendet weiterhin seinen bestehenden aktiven 3.2.12-Dateinamen als Austauschziel. Die vorhandenen Pack-UUIDs sind unverändert, die Bedrock-Version wird auf 3.2.18 angehoben.

Prüfstand: Archivintegrität, alle 851 genehmigten Quader, Verweise, gleiche Java-/Bedrock-Texturatlanten, erhaltene Alt-Assets und sieben Mappingdefinitionen wurden statisch geprüft. Das ist keine bestandene grafische Java-/Bedrock-/Geyser-Abnahme. Die Trägerposition der unsichtbaren ArmorStands bleibt bis zum echten Client-Test konfigurierbar; Standard ist Modellbasis minus 1,6875 Blöcke. Keine automatische Server-Neustartfreigabe aus diesem Dokument ableiten.

Aktuelle Prüfsummen:

- SHA-256 `PAP-SMP-Full-Java-3.2.16-Karten-MC-1.21.11.zip`: `27e88e9afe3eb70e9657720c8a76bd33eac3f4dde53e9cff6181a677298892db`
- SHA-256 `PAP-SMP-Bedrock-3.2.16-Karten.mcpack`: `2ab2259b079078d5fb010eaa81d01c8ca8caf987cc9ca30e40727d476d101407`
- SHA-256 `PAP-SMP-Custom-Mappings-3.2.16.json`: `5ea00d22cb2829ad7379ba582f5909f5c86d5356cc3158598ff9ba4ad4c98882`
- Java resource-pack-sha1: `604554fab749e76564f7ed27e406c2865b08126e`

---

## Historische Hinweise – nachrangig zur Ergänzung oben

# PAP SMP 3.2.16 – Karten & Werte

Kompaktes überlappendes Original-Website-Logo, halbtransparentes Panel, Phasenstreifen mit Countdown, zwei Cash-/Shards-Karten und lesbare Statistikzeilen. Die Anzeige ist 126 native Pixel breit und 197 Pixel hoch (vorher 148 × 246): etwa 15 % schmaler und 20 % niedriger. Bei GUI 3 beträgt die Breite einschließlich Rand 378 Bildschirm-Pixel statt 444. Die Schriftgröße bleibt erhalten, das Logo misst 90 × 82 native Pixel.

Java verwendet 15 native Zeilen einschließlich leerer Abstandszeilen. Dadurch liegt Minecrafts eigener Hintergrund vollständig innerhalb des Panels. Die Hauptfläche nutzt Alpha 128/255 und ergibt mit dem gewöhnlichen nativen Hintergrund etwa 65 % Deckkraft. Die tatsächliche Deckkraft hängt auch von den Text-Hintergrundeinstellungen des Clients ab. Bei maximaler Hintergrunddeckkraft im Client kann der native Hintergrund weiterhin deckend sein. Bedrock verwendet für das eigene Panel Alpha 166/255. Währungskarten bleiben etwas kräftiger. Es gibt keine globalen Shader-Änderungen und keine erzwungenen Client-Einstellungen. Die Alpha bleibt geschlossen.

## Bestehenden Server aktualisieren

1. Server ordentlich stoppen und Konfigurationen, UI-/Visual-JARs und Bedrock-Pack außerhalb aktiver Verzeichnisse sichern.
2. Genau eine UI-Version und einen Visual-Zusatz aktiv halten: pap-smp-ui-1.0.3-card.1.jar sowie pap-smp-companion-visual-0.4.5-ui.1.jar. Companion 1.1.2 bleibt erhalten.
3. Genau ein PAP-Bedrock-Pack mit UUID db742887-aab4-45b8-a41a-58433fd13b5b verwenden: PAP-SMP-Bedrock-3.2.16-Karten.mcpack. Alte Packdatei aus dem aktiven Geyser-packs-Verzeichnis nehmen.
4. Die vorhandenen 42 Custom-Mappings bleiben bytegleich. Bei bestehenden Servern keine zweite Mapping-Datei daneben installieren. Die mitgelieferte Mapping-Datei ist für eine Neuinstallation vorgesehen.
5. server.properties: bestehende resource-pack-id behalten, URL und Hash gemeinsam ersetzen:
   resource-pack=https://papsmp.de/downloads/PAP-SMP-Full-Java-3.2.16-Karten-MC-1.21.11.zip
   resource-pack-sha1=f34971b99265a50ef1ca4b40ad3de47db86a1d0b
6. PAP-SMP-UI/config.yml pack.sha1 und PAP-SMP-Teleport/config.yml menu-resourcepack.full-pack-sha1 auf dieselbe SHA-1 setzen. Bedrock-Pfad: packs/PAP-SMP-Bedrock-3.2.16-Karten.mcpack; SHA-256: c7af02462a5341a93a8a66b21ee082568b01fba38444577250151a29b61578a5.
7. Den scoreboard-Abschnitt der geprüften privaten TAB-Konfiguration einsetzen. Spielerliste, Header/Footer und übrige TAB-Einstellungen bleiben erhalten. Doctor erwartet UI 1.0.3-card.1 und Visual 0.4.5-ui.1.
8. Server starten, papdoctor und Pack-Gates prüfen. Spieler vollständig neu verbinden und das aktualisierte Pack laden.

## Rückweg

Gesicherte Konfigurationen, alte UI-/Visual-JARs und altes Pack als zusammengehörigen Stand wiederherstellen. Welten, Inventare, Geld, Shards und Companion-Besitz werden durch das Update nicht ersetzt. Frühere öffentliche Downloads bleiben unverändert.
